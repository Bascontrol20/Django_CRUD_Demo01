from django.contrib import admin
from .models import Position,Employee

admin.site.register(Position)
admin.site.register(Employee)